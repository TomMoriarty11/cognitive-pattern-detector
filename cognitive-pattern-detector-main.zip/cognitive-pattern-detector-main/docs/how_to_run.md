# How to Run the Cognitive Pattern Detector

# Step 1: Clone or Download
git clone https://github.com/yourusername/cognitive-pattern-detector.git
cd cognitive-pattern-detector
Or Download the ZIP file and extract it. 

# Step 2: Install Dependencies
pip install -r requirements.txt

# Step 4: Run the Script
Open the visuals/pattern_graph.png to see dips and spikes in cognitive performance.
